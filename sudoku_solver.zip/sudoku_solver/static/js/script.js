document.addEventListener('DOMContentLoaded', () => {
    const gridElement = document.getElementById('sudoku-grid');
    const solveButton = document.getElementById('solve-button');
    const clearButton = document.getElementById('clear-button');
    const statusMessage = document.getElementById('status-message');
    const cells = [];

    // --- Initialize Lenis for smooth scrolling ---
    try {
        const lenis = new Lenis();
        function raf(time) {
            lenis.raf(time);
            requestAnimationFrame(raf);
        }
        requestAnimationFrame(raf);
    } catch (e) {
        console.warn("Lenis library not found or failed to initialize:", e);
    }


    // --- p5.js Sketch for Background ---
    if (typeof p5 !== 'undefined') {
        let p5Sketch = function(p) {
            let particles = [];
            const numParticles = 50;

            class Particle {
                constructor() {
                    this.x = p.random(p.width);
                    this.y = p.random(p.height);
                    this.vx = p.random(-0.5, 0.5);
                    this.vy = p.random(-0.5, 0.5);
                    this.alpha = p.random(50, 150);
                    this.size = p.random(2, 5);
                }

                update() {
                    this.x += this.vx;
                    this.y += this.vy;

                    if (this.x < 0 || this.x > p.width) this.vx *= -1;
                    if (this.y < 0 || this.y > p.height) this.vy *= -1;
                }

                show() {
                    p.noStroke();
                    p.fill(200, 200, 240, this.alpha); // Light blueish-purple
                    p.ellipse(this.x, this.y, this.size);
                }
            }

            p.setup = function() {
                let canvas = p.createCanvas(p.windowWidth, p.windowHeight);
                canvas.parent('p5-background'); // Attach to the div
                for (let i = 0; i < numParticles; i++) {
                    particles.push(new Particle());
                }
            };

            p.draw = function() {
                p.clear();
                for (let particle of particles) {
                    particle.update();
                    particle.show();
                }
            };

            p.windowResized = function() {
                p.resizeCanvas(p.windowWidth, p.windowHeight);
            };
        };
        new p5(p5Sketch);
    } else {
        console.warn("p5.js library not found.");
    }


    // --- Sudoku Grid Generation and Logic ---
    function createGrid() {
        gridElement.innerHTML = ''; // Clear previous grid
        cells.length = 0; // Clear cells array
        for (let i = 0; i < 81; i++) {
            const input = document.createElement('input');
            input.type = 'number';
            input.min = '1';
            input.max = '9';
            input.maxLength = '1';
            input.dataset.index = i;

            input.addEventListener('input', function(e) {
                this.value = this.value.replace(/[^1-9]/g, '');
                if (this.value.length > 1) {
                    this.value = this.value.slice(0, 1);
                }
            });
            input.addEventListener('keydown', handleKeyDown);

            gridElement.appendChild(input);
            cells.push(input);
        }
    }

    function handleKeyDown(e) {
        const index = parseInt(e.target.dataset.index);
        let nextIndex;
        switch(e.key) {
            case 'ArrowUp':
                nextIndex = index - 9;
                break;
            case 'ArrowDown':
                nextIndex = index + 9;
                break;
            case 'ArrowLeft':
                nextIndex = index - 1;
                break;
            case 'ArrowRight':
                nextIndex = index + 1;
                break;
            default:
                return;
        }

if (nextIndex >= 0 && nextIndex < 81) {
            if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
                e.preventDefault();
            }
            if ((e.key === 'ArrowLeft' && index % 9 === 0) || (e.key === 'ArrowRight' && (index + 1) % 9 === 0)) {
                // Don't move if at edge of row
            } else {
                 cells[nextIndex]?.focus();
            }
        }
    }


    function getBoard() {
        const board = [];
        let row = [];
        cells.forEach((cell, i) => {
            row.push(cell.value ? parseInt(cell.value) : 0);
            if ((i + 1) % 9 === 0) {
                board.push(row);
                row = [];
            }
        });
        return board;
    }

    function animateSolution(solutionBoard, originalBoard) {
        const unsolvedCellsToAnimate = [];
        cells.forEach((cell, i) => {
            const row = Math.floor(i / 9);
            const col = i % 9;
            const solutionValue = solutionBoard[row][col];
            const originalValue = originalBoard[row][col];

            if ( (originalValue === 0 || originalValue === '') && solutionValue !== 0) {
                cell.classList.remove('fixed-number');
                cell.classList.add('solved-number');
                cell.value = '';
                unsolvedCellsToAnimate.push({
                    element: cell,
                    value: solutionValue
                });
            } else if (solutionValue !== 0) {
                cell.classList.add('fixed-number');
                cell.value = solutionValue;
                cell.disabled = true;
            } else {
                 cell.value = '';
                 cell.disabled = false;
            }
        });

        if (typeof anime !== 'undefined') {
            anime({
                targets: unsolvedCellsToAnimate.map(item => item.element),
                opacity: [0, 1],
                scale: [0.5, 1],
                duration: 600,
                delay: anime.stagger(30, { grid: [9, 9], from: 'center' }),
                easing: 'easeOutExpo',
                begin: function(anim) {
                    anim.animatables.forEach((target, index) => {
                        target.target.value = unsolvedCellsToAnimate[index].value;
                        target.target.disabled = true;
                    });
                },
                complete: function() {
                    cells.forEach((cellElem, i) => {
                        const row = Math.floor(i / 9);
                        const col = i % 9;
                        if (solutionBoard[row][col] !== 0) {
                            cellElem.disabled = true;
                            if (!(originalBoard[row][col] === 0 || originalBoard[row][col] === '')) {
                                cellElem.classList.add('fixed-number');
                            } else {
                                cellElem.classList.add('solved-number');
                            }
                        }
                    });
                }
            });
        } else { // Fallback if anime.js is not loaded
            unsolvedCellsToAnimate.forEach(item => {
                item.element.value = item.value;
                item.element.disabled = true;
            });
             cells.forEach((cellElem, i) => {
                const row = Math.floor(i / 9);
                const col = i % 9;
                if (solutionBoard[row][col] !== 0) {
                    cellElem.disabled = true;
                    if (!(originalBoard[row][col] === 0 || originalBoard[row][col] === '')) {
                        cellElem.classList.add('fixed-number');
                    } else {
                        cellElem.classList.add('solved-number');
                    }
                }
            });
        }
    }


    async function handleSolve() {
        solveButton.classList.add('loading');
        solveButton.disabled = true;
        statusMessage.textContent = 'Solving...';
        statusMessage.className = '';

        const currentBoard = getBoard();
        cells.forEach((cell, i) => {
            const row = Math.floor(i / 9);
            const col = i % 9;
            if (currentBoard[row][col] !== 0) {
                cell.classList.add('fixed-number');
                cell.disabled = true;
            } else {
                cell.classList.remove('fixed-number', 'solved-number');
                cell.disabled = false;
            }
        });


        try {
            const response = await fetch('/solve', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ board: currentBoard }),
            });

            const result = await response.json();

            if (response.ok) {
                if (result.status === 'solved') {
                    animateSolution(result.solution, currentBoard);
                    statusMessage.textContent = 'Sudoku Solved!';
                    statusMessage.className = 'success';
                    if (typeof anime !== 'undefined') {
                        anime({
                            targets: solveButton,
                            backgroundColor: ['#6a11cb', '#2ecc71', '#6a11cb'],
                            duration: 1500,
                            easing: 'easeInOutQuad'
                        });
                    }
                } else if (result.status === 'unsolvable') {
                    statusMessage.textContent = 'This Sudoku is unsolvable or has errors.';
                    statusMessage.className = 'error';
                    cells.forEach((cell, i) => {
                        const row = Math.floor(i / 9);
                        const col = i % 9;
                        if (currentBoard[row][col] === 0) {
                            cell.disabled = false;
                        }
                    });
                }
            } else {
                statusMessage.textContent = `Error: ${result.error || 'Could not solve.'}`;
                statusMessage.className = 'error';
                cells.forEach(cell => {
                    if (!cell.classList.contains('fixed-number')) {
                        cell.disabled = false;
                    }
                });
            }
        } catch (error) {
            console.error('Fetch error:', error);
            statusMessage.textContent = 'Network error. Could not reach server.';
            statusMessage.className = 'error';
            cells.forEach(cell => {
                 if (!cell.classList.contains('fixed-number')) {
                     cell.disabled = false;
                 }
            });
        } finally {
            solveButton.classList.remove('loading');
            solveButton.disabled = false;
        }
    }
function clearGrid() {
        cells.forEach(cell => {
            cell.value = '';
            cell.disabled = false;
            cell.classList.remove('solved-number', 'fixed-number');
        });
        statusMessage.textContent = '';
        statusMessage.className = '';
        if(cells.length > 0) cells[0].focus();

        if (typeof anime !== 'undefined') {
            anime({
                targets: clearButton,
                scale: [1, 1.1, 1],
                duration: 300,
                easing: 'easeInOutSine'
            });
        }
    }

    // --- Event Listeners ---
    solveButton.addEventListener('click', () => {
        if (typeof anime !== 'undefined') {
            anime({
                targets: solveButton,
                scale: [
                    { value: 0.9, duration: 100, easing: 'easeOutExpo' },
                    { value: 1, duration: 200, easing: 'easeInExpo' }
                ],
                complete: handleSolve
            });
        } else {
            handleSolve();
        }
    });

    clearButton.addEventListener('click', clearGrid);

    // --- Initial Setup ---
    createGrid();
    if(cells.length > 0) cells[0].focus();
});