from flask import Flask, render_template, request, jsonify
import copy

app = Flask(__name__)

# --- Sudoku Solver Logic ---
def is_valid(board, row, col, num):
    # Check row
    for x in range(9):
        if board[row][x] == num:
            return False
    # Check column
    for x in range(9):
        if board[x][col] == num:
            return False
    # Check 3x3 subgrid
    start_row, start_col = 3 * (row // 3), 3 * (col // 3)
    for i in range(3):
        for j in range(3):
            if board[i + start_row][j + start_col] == num:
                return False
    return True

def find_empty(board):
    for i in range(9):
        for j in range(9):
            if board[i][j] == 0:  # 0 represents an empty cell
                return (i, j)
    return None

def solve_sudoku_util(board):
    find = find_empty(board)
    if not find:
        return True  # Solved
    else:
        row, col = find

    for num in range(1, 10):
        if is_valid(board, row, col, num):
            board[row][col] = num
            if solve_sudoku_util(board):
                return True
            board[row][col] = 0  # Backtrack
    return False

def solve_sudoku(board):
    board_copy = [row[:] for row in board]
    if solve_sudoku_util(board_copy):
        return board_copy
    return None
# --- End Sudoku Solver Logic ---


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/solve', methods=['POST'])
def solve():
    data = request.get_json()
    board = data.get('board')

    if not board or len(board) != 9 or not all(len(row) == 9 for row in board):
        return jsonify({'error': 'Invalid board format.'}), 400

    parsed_board = []
    try:
        for r_idx, row in enumerate(board):
            parsed_row = []
            for c_idx, cell in enumerate(row):
                if isinstance(cell, str) and cell.strip() == '':
                    parsed_row.append(0)
                elif isinstance(cell, (int, str)) and str(cell).isdigit() and 1 <= int(cell) <= 9:
                    parsed_row.append(int(cell))
                elif cell == 0:
                     parsed_row.append(0)
                else:
                    app.logger.warning(f"Invalid cell value '{cell}' at ({r_idx},{c_idx}), treating as empty.")
                    parsed_row.append(0)
            parsed_board.append(parsed_row)
    except ValueError:
        return jsonify({'error': 'Invalid input in board cells. Use numbers 1-9 or leave empty.'}), 400


    solution = solve_sudoku(parsed_board)

    if solution:
        return jsonify({'solution': solution, 'status': 'solved'})
    else:
        return jsonify({'status': 'unsolvable', 'original_board': parsed_board})


if __name__ == '__main__':
    app.run(debug=False) # Set debug=False for production on Vercel